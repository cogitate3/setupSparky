#!/bin/bash
# ANGRYsearch uninstall script for Debian based distros

rm -rfv $(find /usr -path "*angrysearch*")
